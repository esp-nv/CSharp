﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P02.MultipleImplementation.Interfaces;
public interface IBirthable
{
    string Birthdate { get; }
}
