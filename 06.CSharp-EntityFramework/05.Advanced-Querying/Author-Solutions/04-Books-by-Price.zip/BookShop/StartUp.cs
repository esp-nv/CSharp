﻿using BookShop.Data;
using BookShop.Initializer;
using Microsoft.EntityFrameworkCore;
using System.Text;

namespace BookShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            BookShopContext context = new BookShopContext();
            

           
            Console.WriteLine(GetBooksByPrice(context));
        }
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            var books =
                context.Books
                .ToArray()
                .Where(c => c.AgeRestriction.ToString().ToLower() == command.ToLower())
                .Select(c => c.Title)
                .OrderBy(c => c);

            StringBuilder sb = new StringBuilder();

            foreach (var book in books)
            {
                sb.AppendLine(book);
            }
            return sb.ToString();
        }
        public static string GetGoldenBooks(BookShopContext context) 
        {
            var books = context.Books
                .ToArray()
                .Where(c => c.EditionType.ToString() == "Gold" && c.Copies < 5000)               
                .Select(c => new {c.Title,c.BookId})
                .OrderBy(c => c.BookId);

            StringBuilder sb = new StringBuilder();

            foreach (var book in books)
            {
                sb.AppendLine(book.Title);
            }
            return sb.ToString();
        }

        public static string GetBooksByPrice(BookShopContext context)
        {
            string[] booksByPrice = context
               .Books
               .Where(b => b.Price > 40)
               .OrderByDescending(b => b.Price)
               .Select(b => $"{b.Title} - ${b.Price:f2}")
               .ToArray();

            return string.Join(Environment.NewLine, booksByPrice);
        }
    }
}


