﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using AutoMapper.QueryableExtensions;
using CarDealer.Data;
using CarDealer.DTO.Export;
using CarDealer.DTO.InportDtos;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            CarDealerContext context = new CarDealerContext();

            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();

            Mapper.Initialize(cfg => cfg.AddProfile(typeof(CarDealerProfile)));

            //string inputJsonSupplies = File.ReadAllText("../../../Datasets/suppliers.json");
            //string inputJsonParts = File.ReadAllText("../../../Datasets/parts.json");
            //string inputJsonCars = File.ReadAllText("../../../Datasets/cars.json");
            //string inputJsonCustomer = File.ReadAllText("../../../Datasets/customers.json");
            //string inputJsonSales = File.ReadAllText("../../../Datasets/sales.json");            
            //string outputSales= ImportSales(context, inputJsonSales);
            //Console.WriteLine(outputSales);

            string output = GetOrderedCustomers(context);
            File.WriteAllText("../../../DatasetsExport/OrderedCustomers.json", output);
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            ImportSupplierDto[] suppliesJson = JsonConvert.DeserializeObject<ImportSupplierDto[]>(inputJson);

            ICollection<Supplier> suplliers = new List<Supplier>();

            foreach (ImportSupplierDto supplie in suppliesJson)
            {
                Supplier supplier = Mapper.Map<Supplier>(supplie);

                suplliers.Add(supplier);
            }

            context.Suppliers.AddRange(suplliers);
            context.SaveChanges();

            return $"Successfully imported {suplliers.Count}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            ImportPartDto[] inportDtos = JsonConvert.DeserializeObject<ImportPartDto[]>(inputJson);
            ICollection<Part> parts = new List<Part>();

           var validSuppliesId = context
                                    .Suppliers
                                    .AsNoTracking()
                                    .Select(s => s.Id)
                                    .ToList();

            foreach (ImportPartDto partDto in inportDtos)
            {
                if (!validSuppliesId.Contains(partDto.SupplierId))
                {
                    continue;
                }
               
                Part part = Mapper.Map<Part>(partDto);
                parts.Add(part);
            }



            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count}.";

        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            var carsDto = JsonConvert.DeserializeObject<ImportCarDto[]>(inputJson);

            ICollection<Car> cars = new List<Car>();

            foreach (ImportCarDto carDto in carsDto)
            {
                Car car = new Car()
                {
                    Make = carDto.Make,
                    Model = carDto.Model,
                    TravelledDistance = carDto.TravelledDistance
                };

                foreach (var part in carDto.PartsId.Distinct())
                {
                    car.PartCars.Add(new PartCar() { PartId = part });
                }
                cars.Add(car);
            }
          
            context.Cars.AddRange(cars);
            context.SaveChanges();

            return $"Successfully imported {cars.Count}.";


        }

        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            var customerDtos = JsonConvert.DeserializeObject<ImportCustomerDto[]>(inputJson);

            ICollection<Customer> customers = new List<Customer>();

            foreach (ImportCustomerDto customerDto in customerDtos)
            {
                Customer customer = Mapper.Map<Customer>(customerDto);
                customers.Add(customer);
            }

            context.Customers.AddRange(customers);
            context.SaveChanges();

            return $"Successfully imported {customers.Count}.";

        }

        public static string ImportSales(CarDealerContext context, string inputJson)
        {
            var saleDtos = JsonConvert.DeserializeObject<ImputSaleDto[]>(inputJson);

            ICollection<Sale> sales = new List<Sale>();

            foreach (ImputSaleDto saleDto in saleDtos)
            {
                Sale sale = Mapper.Map<Sale>(saleDto);

                sales.Add(sale);
            }

            context.Sales.AddRange(sales);
            context.SaveChanges();

            return $"Successfully imported {sales.Count}.";

        }

        public static string GetOrderedCustomers(CarDealerContext context)
        {
            ExportCustomerDto[] orderedCustomers = context
                                            .Customers
                                            .AsNoTracking()
                                            .OrderBy(c => c.BirthDate)
                                            .ThenBy(c => c.IsYoungDriver)
                                            .Select( c => new ExportCustomerDto()
                                            {
                                                Name = c.Name,
                                                BirthDate = c.BirthDate.ToString("dd/MM/yyyy"),
                                                IsYoungDriver = c.IsYoungDriver
                                            })
                                            .ToArray();

            return JsonConvert.SerializeObject(orderedCustomers, Formatting.Indented);
        }
    }
}