﻿using AutoMapper;
using CarDealer.DTO.Export;
using CarDealer.DTO.InportDtos;
using CarDealer.Models;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            //Import
            this.CreateMap<ImportSupplierDto, Supplier>();

            this.CreateMap<ImportPartDto, Part>();

            this.CreateMap<ImportCustomerDto, Customer>();

            this.CreateMap<ImputSaleDto, Sale>();

            //Export
            this.CreateMap<Customer, ExportCustomerDto>()
                .ForMember(d=>d.BirthDate, mo => mo.MapFrom(s => s.BirthDate.ToString("dd/MM/yyyy")));

                  
        }
    }
}
