﻿using CarDealer.Models;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace CarDealer.DTO.Export
{
    [JsonObject]
    public class ExportCarsMakeToyota
    {
        [JsonProperty(nameof(Id))]
        public int Id { get; set; }

        [JsonProperty(nameof(Make))]
        public string Make { get; set; }

        [JsonProperty(nameof(Model))]
        public string Model { get; set; }

        [JsonProperty(nameof(TravelledDistance))]
        public long TravelledDistance { get; set; }
       
    }
}
