﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.DTO.Export
{
    [JsonObject]
    public class ExportCustomerDto
    {
        [JsonProperty(nameof(Name))]
        public string Name { get; set; }

        [JsonProperty(nameof(BirthDate))]
        public string BirthDate { get; set; }

        [JsonProperty(nameof(IsYoungDriver))]
        public bool IsYoungDriver { get; set; }
    }
}
