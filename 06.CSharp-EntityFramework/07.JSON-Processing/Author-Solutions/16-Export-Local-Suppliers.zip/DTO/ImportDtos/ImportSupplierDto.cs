﻿using Newtonsoft.Json;

namespace CarDealer.DTO.InportDtos
{
    [JsonObject]
    public class ImportSupplierDto
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("isImporter")]
        public bool IsImporter { get; set; }
    }
}
