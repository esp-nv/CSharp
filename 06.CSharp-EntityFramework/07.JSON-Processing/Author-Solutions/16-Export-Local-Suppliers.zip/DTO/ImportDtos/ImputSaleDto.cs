﻿using Newtonsoft.Json;

namespace CarDealer.DTO.InportDtos
{
    [JsonObject]
    public class ImputSaleDto
    {
        [JsonProperty("carId")]
        public int CarId { get; set; }

        [JsonProperty("customerId")]
        public int CustomerId { get; set; }

        [JsonProperty("discount")]
        public decimal Discount { get; set; }


    }
}
