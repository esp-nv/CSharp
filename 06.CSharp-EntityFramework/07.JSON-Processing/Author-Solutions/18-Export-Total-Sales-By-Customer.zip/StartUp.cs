﻿using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace CarDealer
{
	public class StartUp
	{
		public void ConfigureServices(IServiceCollection services)
		{
			services.AddDbContext<CarDealerContext>();
		}

		public static void Main(string[] args)
		{

			//Judge don't like this approach
			//Mapper.Initialize(cfg => cfg.AddProfile(typeof(CarDealerProfile)));

			using (var context = new CarDealerContext())
			{
				//Query 9. Import Suppliers
				//string inputJson = File.ReadAllText("../../../Datasets/suppliers.json");
				//Console.WriteLine(ImportSuppliers(context, inputJson));

				//Query 10. Import Parts
				//string inputJson = File.ReadAllText("../../../Datasets/parts.json");
				//Console.WriteLine(ImportParts(context, inputJson));

				//Query 11. Import Cars
				//string inputJson = File.ReadAllText("../../../Datasets/cars.json");
				//Console.WriteLine(ImportCars(context, inputJson));

				//Query 12. Import Customers
				//string inputJson = File.ReadAllText("../../../Datasets/customers.json");
				//Console.WriteLine(ImportCustomers(context, inputJson));

				//Query 13. Import Sales
				//string inputJson = File.ReadAllText("../../../Datasets/sales.json");
				//Console.WriteLine(ImportSales(context, inputJson));

				//Query 14. Export Ordered Customers
				//File.WriteAllText("../../../Results/ordered-customers.json", GetOrderedCustomers(context));

				//Query 15. Export Cars from Make Toyota
				//File.WriteAllText("../../../Results/toyota-cars.json", GetCarsFromMakeToyota(context));

				//Query 16. Export Local Suppliers
				//File.WriteAllText("../../../Results/local-suppliers.json", GetLocalSuppliers(context));

				//Query 17. Export Cars with Their List of Parts
				//File.WriteAllText("../../../Results/cars-and-parts.json", GetCarsWithTheirListOfParts(context));

				//Query 18. Export Total Sales by Customer
				File.WriteAllText("../../../Results/customers-total-sales.json", GetTotalSalesByCustomer(context));

				//Query 19. Export Sales with Applied Discount
				//File.WriteAllText("../../../Results/sales-discounts.json", GetSalesWithAppliedDiscount(context));
			}
		}

		//Query 9. Import Suppliers
		public static string ImportSuppliers(CarDealerContext context, string inputJson)
		{
			var config = new MapperConfiguration(cfg => cfg.AddProfile<CarDealerProfile>());
			IMapper mapper = new Mapper(config);

			SupplierDTO[] supplierDTOs = JsonConvert.DeserializeObject<SupplierDTO[]>(inputJson);

			Supplier[] suppliers = mapper.Map<Supplier[]>(supplierDTOs);

			int importedCount = 0;

			foreach (var supplier in suppliers)
			{
				context.Suppliers.Add(supplier);
				context.SaveChanges();
				importedCount++;
			}

			return $"Successfully imported {importedCount}.";
		}

		//Query 10. Import Parts
		public static string ImportParts(CarDealerContext context, string inputJson)
		{
			var config = new MapperConfiguration(cfg => cfg.AddProfile<CarDealerProfile>());
			IMapper mapper = new Mapper(config);

			PartDTO[] partDTOs = JsonConvert.DeserializeObject<PartDTO[]>(inputJson);

			Part[] parts = mapper.Map<Part[]>(partDTOs);

			int[] suppliersIds = context.Suppliers
				.Select(s => s.Id)
				.ToArray();

			int importedCount = 0;

			foreach (var part in parts.Where(p => suppliersIds.Contains(p.SupplierId)))
			{
				context.Parts.Add(part);
				context.SaveChanges();
				importedCount++;
			}

			return $"Successfully imported {importedCount}.";
		}

		//Query 11. Import Cars
		public static string ImportCars(CarDealerContext context, string inputJson)
		{
			var config = new MapperConfiguration(cfg => cfg.AddProfile<CarDealerProfile>());
			IMapper mapper = new Mapper(config);

			CarDTO[] carDTOs = JsonConvert.DeserializeObject<CarDTO[]>(inputJson);

			int[] partIds = context.Parts
				.Select(p => p.Id)
				.ToArray();

			int importedCars = 0;
			List<PartCar> partCars = new List<PartCar>();

			foreach (CarDTO carDTO in carDTOs)
			{
				Car car = mapper.Map<Car>(carDTO);
				context.Cars.Add(car);
				context.SaveChanges();
				importedCars++;

				foreach (int partId in carDTO.PartsId
												.Distinct()
												.Where(partId => partIds.Contains(partId)))
				{
					partCars.Add(new PartCar
					{
						CarId = car.Id,
						PartId = partId
					});
				}
			}

			context.PartsCars.AddRange(partCars);
			context.SaveChanges();

			return $"Successfully imported {importedCars}.";
		}

		//Query 12. Import Customers
		public static string ImportCustomers(CarDealerContext context, string inputJson)
		{
			var config = new MapperConfiguration(cfg => cfg.AddProfile<CarDealerProfile>());
			IMapper mapper = new Mapper(config);

			CustomersDTO[] customersDTOs = JsonConvert.DeserializeObject<CustomersDTO[]>(inputJson);

			Customer[] customers = mapper.Map<Customer[]>(customersDTOs);

			int importedCustomers = 0;

			foreach (Customer customer in customers)
			{
				context.Customers.Add(customer);
				context.SaveChanges();
				importedCustomers++;
			}

			return $"Successfully imported {importedCustomers}.";
		}

		//Query 13. Import Sales
		public static string ImportSales(CarDealerContext context, string inputJson)
		{
			var config = new MapperConfiguration(cfg => cfg.AddProfile<CarDealerProfile>());
			IMapper mapper = new Mapper(config);

			SaleDTO[] saleDTOs = JsonConvert.DeserializeObject<SaleDTO[]>(inputJson);

			Sale[] sales = mapper.Map<Sale[]>(saleDTOs);

			int importedSales = 0;

			foreach (Sale sale in sales)
			{
				context.Sales.Add(sale);
				context.SaveChanges();
				importedSales++;
			}

			return $"Successfully imported {importedSales}.";
		}

		//Query 14. Export Ordered Customers
		public static string GetOrderedCustomers(CarDealerContext context)
		{
			var customers = context.Customers
				.OrderBy(c => c.BirthDate)
				.ThenByDescending(c => c.IsYoungDriver == false)
				.Select(c => new
				{
					c.Name,
					BirthDate = c.BirthDate.ToString("dd/MM/yyyy"),
					c.IsYoungDriver
				})
				.ToArray();

			string output = JsonConvert.SerializeObject(customers, Formatting.Indented);

			return output;
		}

		//Query 15. Export Cars from Make Toyota
		public static string GetCarsFromMakeToyota(CarDealerContext context)
		{
			var cars = context.Cars
				.Where(c => c.Make == "Toyota")
				.OrderBy(c => c.Model)
				.ThenByDescending(c => c.TraveledDistance)
				.Select(c => new
				{
					c.Id,
					c.Make,
					c.Model,
					c.TraveledDistance
				})
				.ToArray();

			//string expectedJson = "[{\"Id\":134,\"Make\":\"Toyota\",\"Model\":\"Camry Hybrid\",\"TraveledDistance\":486872832},{\"Id\":139,\"Make\":\"Toyota\",\"Model\":\"Camry Hybrid\",\"TraveledDistance\":397831570},{\"Id\":117,\"Make\":\"Toyota\",\"Model\":\"Camry Hybrid\",\"TraveledDistance\":217630531},{\"Id\":136,\"Make\":\"Toyota\",\"Model\":\"Camry Hybrid\",\"TraveledDistance\":193362513},{\"Id\":112,\"Make\":\"Toyota\",\"Model\":\"Camry Hybrid\",\"TraveledDistance\":151868293},{\"Id\":120,\"Make\":\"Toyota\",\"Model\":\"Corolla\",\"TraveledDistance\":485584239},{\"Id\":109,\"Make\":\"Toyota\",\"Model\":\"Corolla\",\"TraveledDistance\":356361379},{\"Id\":124,\"Make\":\"Toyota\",\"Model\":\"Corolla\",\"TraveledDistance\":333412512},{\"Id\":113,\"Make\":\"Toyota\",\"Model\":\"Corolla\",\"TraveledDistance\":230556000},{\"Id\":122,\"Make\":\"Toyota\",\"Model\":\"Corolla\",\"TraveledDistance\":196587490},{\"Id\":115,\"Make\":\"Toyota\",\"Model\":\"Corolla\",\"TraveledDistance\":172436753},{\"Id\":104,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":508864707},{\"Id\":130,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":424624116},{\"Id\":132,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":332788407},{\"Id\":118,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":280666484},{\"Id\":125,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":208912076},{\"Id\":137,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":191675886},{\"Id\":108,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":142914233},{\"Id\":111,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":141313729},{\"Id\":135,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":126607020},{\"Id\":121,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":78228066},{\"Id\":114,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":65891391},{\"Id\":106,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":64266329},{\"Id\":128,\"Make\":\"Toyota\",\"Model\":\"Prius\",\"TraveledDistance\":8676482},{\"Id\":105,\"Make\":\"Toyota\",\"Model\":\"Tacoma\",\"TraveledDistance\":431663130},{\"Id\":107,\"Make\":\"Toyota\",\"Model\":\"Tacoma\",\"TraveledDistance\":426059006},{\"Id\":129,\"Make\":\"Toyota\",\"Model\":\"Tacoma\",\"TraveledDistance\":425742267},{\"Id\":116,\"Make\":\"Toyota\",\"Model\":\"Tacoma\",\"TraveledDistance\":328571532},{\"Id\":126,\"Make\":\"Toyota\",\"Model\":\"Tacoma\",\"TraveledDistance\":174113404},{\"Id\":138,\"Make\":\"Toyota\",\"Model\":\"Tacoma\",\"TraveledDistance\":157810668},{\"Id\":119,\"Make\":\"Toyota\",\"Model\":\"Tacoma\",\"TraveledDistance\":147379564},{\"Id\":133,\"Make\":\"Toyota\",\"Model\":\"Tacoma\",\"TraveledDistance\":89596390},{\"Id\":123,\"Make\":\"Toyota\",\"Model\":\"Yaris\",\"TraveledDistance\":439493520},{\"Id\":110,\"Make\":\"Toyota\",\"Model\":\"Yaris\",\"TraveledDistance\":285031257},{\"Id\":127,\"Make\":\"Toyota\",\"Model\":\"Yaris\",\"TraveledDistance\":18776234},{\"Id\":131,\"Make\":\"Toyota\",\"Model\":\"Yaris\",\"TraveledDistance\":17169781}]";

			//Console.WriteLine(JToken.Parse(expectedJson));

			string output = JsonConvert.SerializeObject(cars, Formatting.Indented);

			return output;
		}

		//Query 16. Export Local Suppliers
		public static string GetLocalSuppliers(CarDealerContext context)
		{
			var suppliers = context.Suppliers
				.Where(s => s.IsImporter == false)
				.Select(s => new
				{
					s.Id,
					s.Name,
					PartsCount = s.Parts.Count()
				})
				.ToArray();

			string output = JsonConvert.SerializeObject(suppliers, Formatting.Indented);

			return output;
		}

		//Query 17. Export Cars with Their List of Parts
		public static string GetCarsWithTheirListOfParts(CarDealerContext context)
		{
			var cars = context.Cars
				.Select(c => new
				{
					car = new
					{
						c.Make,
						c.Model,
						c.TraveledDistance
					},
					parts = c.PartsCars
						.Select(p => new
						{
							p.Part.Name,
							Price = $"{p.Part.Price:F2}"
						})
						.ToArray()
				})
			.ToArray();

			string output = JsonConvert.SerializeObject(cars, Formatting.Indented);

			return output;
		}

		//Query 18. Export Total Sales by Customer
		public static string GetTotalSalesByCustomer(CarDealerContext context)
		{
			var customerSales = context.Customers
				 .Where(c => c.Sales.Any())
				 .Select(c => new
				 {
					 fullName = c.Name,
					 boughtCars = c.Sales.Count(),
					 salePrices = c.Sales.SelectMany(x => x.Car.PartsCars.Select(x => x.Part.Price))
				 })
				 .ToArray();

			var totalSalesByCustomer = customerSales.Select(t => new
			{
				t.fullName,
				t.boughtCars,
				spentMoney = t.salePrices.Sum()
			})
			.OrderByDescending(t => t.spentMoney)
			.ThenByDescending(t => t.boughtCars)
			.ToArray();

			string output = JsonConvert.SerializeObject(totalSalesByCustomer, Formatting.Indented);

			return output;
		}

		//Query 19. Export Sales with Applied Discount
		public static string GetSalesWithAppliedDiscount(CarDealerContext context)
		{
			var sales = context.Sales
				.Take(10)
				.Select(s => new
				{
					car = new { s.Car.Make, s.Car.Model, s.Car.TraveledDistance },
					customerName = s.Customer.Name,
					discount = $"{s.Discount:F2}",
					price = $"{s.Car.PartsCars.Select(p => p.Part.Price).Sum().ToString():F2}",
					priceWithDiscount = getPriceWithDiscount(s.Car.PartsCars.Select(p => p.Part.Price).Sum(), s.Discount)
				})
				.ToArray();

			string expectedJson = "[{\"car\":{\"Make\":\"Toyota\",\"Model\":\"Tacoma\",\"TraveledDistance\":431663130},\"customerName\":\"Ann Mcenaney\",\"discount\":\"30.00\",\"price\":\"117.97\",\"priceWithDiscount\":\"82.58\"},{\"car\":{\"Make\":\"Ferrari\",\"Model\":\"275\",\"TraveledDistance\":448008546},\"customerName\":\"Faustina Burgher\",\"discount\":\"50.00\",\"price\":\"256.23\",\"priceWithDiscount\":\"128.12\"},{\"car\":{\"Make\":\"Skoda\",\"Model\":\"Rapid Spaceback\",\"TraveledDistance\":371247268},\"customerName\":\"Louann Holzworth\",\"discount\":\"0.00\",\"price\":\"346.96\",\"priceWithDiscount\":\"346.96\"},{\"car\":{\"Make\":\"Seat\",\"Model\":\"Mii\",\"TraveledDistance\":20379344},\"customerName\":\"Hipolito Lamoreaux\",\"discount\":\"40.00\",\"price\":\"388.22\",\"priceWithDiscount\":\"232.93\"},{\"car\":{\"Make\":\"Ferrari\",\"Model\":\"F430\",\"TraveledDistance\":403805820},\"customerName\":\"Zada Attwood\",\"discount\":\"0.00\",\"price\":\"1326.12\",\"priceWithDiscount\":\"1326.12\"},{\"car\":{\"Make\":\"Rolls-Royce\",\"Model\":\"Phantom\",\"TraveledDistance\":208114157},\"customerName\":\"Daniele Zarate\",\"discount\":\"15.00\",\"price\":\"569.38\",\"priceWithDiscount\":\"483.97\"},{\"car\":{\"Make\":\"Opel\",\"Model\":\"Omega\",\"TraveledDistance\":109910837},\"customerName\":\"Zada Attwood\",\"discount\":\"30.00\",\"price\":\"351.97\",\"priceWithDiscount\":\"246.38\"},{\"car\":{\"Make\":\"BMW\",\"Model\":\"1M Coupe\",\"TraveledDistance\":39826890},\"customerName\":\"Marcelle Griego\",\"discount\":\"0.00\",\"price\":\"1777.22\",\"priceWithDiscount\":\"1777.22\"},{\"car\":{\"Make\":\"BMW\",\"Model\":\"X6 M\",\"TraveledDistance\":227443571},\"customerName\":\"Emmitt Benally\",\"discount\":\"10.00\",\"price\":\"5504.59\",\"priceWithDiscount\":\"4954.13\"},{\"car\":{\"Make\":\"Skoda\",\"Model\":\"Citigo\",\"TraveledDistance\":326326638},\"customerName\":\"Cinthia Lasala\",\"discount\":\"30.00\",\"price\":\"180.78\",\"priceWithDiscount\":\"126.55\"}]";

			Console.WriteLine(JToken.Parse(expectedJson));

			string output = JsonConvert.SerializeObject(sales, Formatting.Indented);

			return output;
		}

		private static string getPriceWithDiscount(decimal price, decimal discount)
			=> $"{price - (price * (discount / 100)):F2}";
	}
}