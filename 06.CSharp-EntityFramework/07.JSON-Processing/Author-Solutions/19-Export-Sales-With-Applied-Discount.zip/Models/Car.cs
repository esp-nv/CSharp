﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CarDealer.Models
{
    public class Car
    {
        public int Id { get; set; }

        [Required]
        public string Make { get; set; }

        [Required]
        public string Model { get; set; }

        public long TraveledDistance { get; set; }

        public ICollection<Sale> Sales { get; set; }

        //[InverseProperty(nameof(PartCar.Car))]
        public ICollection<PartCar> PartsCars { get; set; } = new List<PartCar>();
    }
}