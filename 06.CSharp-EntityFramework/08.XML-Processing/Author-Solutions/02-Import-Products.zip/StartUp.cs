﻿using ProductShop.Data;
using ProductShop.DTOs.Import;
using ProductShop.Models;
using System.Xml.Serialization;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main()
        {
            ProductShopContext context = new ProductShopContext();

            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();
            //Console.WriteLine("DB is created!!!!!");

            string xml = File.ReadAllText(Configuration.xmlFolderInsert + @"\products.xml");
            string result = ImportProducts(context, xml);
            Console.WriteLine(result);
        }

        public static string ImportUsers(ProductShopContext context, string inputXml)
        {
            ImportUsersDTO[] xmlUsers = Deserialize<ImportUsersDTO[]>(inputXml, "Users");

            User[] users = xmlUsers.Select(u => new User
            {
                FirstName = u.FirstName,
                LastName = u.LastName,
                Age = u.Age
            }).ToArray();

            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Length}";
        }

        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            ImportProductsDTO[] xmlProducts = Deserialize<ImportProductsDTO[]>(inputXml, "Products");

            ICollection<Product> validProducts = new List<Product>();
            foreach (var product in xmlProducts)
            {
                //if (!context.Users.Any(u => u.Id == product.SellerId))
                //{
                //    continue;
                //}

                Product curr = new Product()
                {
                    Name = product.Name,
                    Price = product.Price,
                    BuyerId = product.BuyerId,
                    SellerId = product.SellerId
                };

                validProducts.Add(curr);
            }

            context.Products.AddRange(validProducts);
            context.SaveChanges();

            return $"Successfully imported {validProducts.Count}";
        }


        private static T Deserialize<T>(string inputXml, string rootName)
        {
            XmlRootAttribute xmlRoot = new XmlRootAttribute(rootName);
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T), xmlRoot);

            using StringReader reader = new StringReader(inputXml);
            T dtos = (T)xmlSerializer
                .Deserialize(reader);

            return dtos;
        }
    }
}