﻿using CarDealer.Data;
using CarDealer.Dtos.Import;
using CarDealer.Models;
using System;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            CarDealerContext context = new CarDealerContext();
            string xml = File.ReadAllText(@"C:\My files\softuni\C# Entity Framework\Extensible Markup Language - XML\CarDealer\Datasets/suppliers.xml");

            string result = ImportSuppliers(context, xml);
            Console.WriteLine(result);
            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();
            //Console.WriteLine("DB is created");
        }

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlRootAttribute xmlRoot = new XmlRootAttribute("Suppliers");
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportSuppliersDTO[]), xmlRoot);

            using StringReader reader = new StringReader(inputXml);
            ImportSuppliersDTO[] supplierDtos = (ImportSuppliersDTO[])xmlSerializer
                .Deserialize(reader);

            Supplier[] suppliers = supplierDtos
                .Select(dto => new Supplier()
                {
                    Name = dto.Name,
                    IsImporter = dto.IsImporter
                })
                .ToArray();

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Length}";
        }
    }
}