﻿using CarDealer.Data;
using CarDealer.Dtos.Import;
using CarDealer.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            CarDealerContext context = new CarDealerContext();
            string xml = File.ReadAllText(@"C:\My files\softuni\C# Entity Framework\Extensible Markup Language - XML\CarDealer\Datasets\customers.xml");

            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();
            //Console.WriteLine("DB is created");
            string result = ImportCustomers(context, xml);
            Console.WriteLine(result);
        }

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            XmlRootAttribute xmlRoot = new XmlRootAttribute("Suppliers");
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ImportSuppliersDTO[]), xmlRoot);

            using StringReader reader = new StringReader(inputXml);
            ImportSuppliersDTO[] supplierDtos = (ImportSuppliersDTO[])xmlSerializer
                .Deserialize(reader);

            Supplier[] suppliers = supplierDtos
                .Select(dto => new Supplier()
                {
                    Name = dto.Name,
                    IsImporter = dto.IsImporter
                })
                .ToArray();

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Length}";
        }

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            XmlRootAttribute root = new XmlRootAttribute("Parts");
            XmlSerializer serializer = new XmlSerializer(typeof(ImportPartsDTO[]), root);

            using StringReader reader = new StringReader(inputXml);
            ImportPartsDTO[] importParts = (ImportPartsDTO[])serializer
                .Deserialize(reader);

            ICollection<Part> validParts = new List<Part>();
            foreach (var part in importParts)
            {
                if(!context.Suppliers.Any(s => s.Id == part.SupplierId))
                {
                    continue;
                }

                Part currPart = new Part()
                {
                    Name = part.Name,
                    Price = part.Price,
                    Quantity = part.Quantity,
                    SupplierId = part.SupplierId
                };

                validParts.Add(currPart);
            }

            context.Parts.AddRange(validParts);
            context.SaveChanges();

            return $"Successfully imported {validParts.Count}";
        }

        public static string ImportCars(CarDealerContext context, string inputXml)
        {
            string root = "Cars";
            ImportCarsDTO[] importCars = Deserialize<ImportCarsDTO[]>(inputXml, root);

            ICollection<Car> cars = new List<Car>();
            foreach (var importedCar in importCars)
            {
                Car currCar = new Car() 
                {
                    Make = importedCar.Make,
                    Model = importedCar.Model,
                    TravelledDistance = importedCar.TraveledDistance
                };

                ICollection<PartCar> partCars = new List<PartCar>();
                foreach (var part in importedCar.Parts.Select(p => p.Id).Distinct())
                {
                    if(!context.Parts.Any(p => p.Id == part))
                    {
                        continue;
                    }

                    partCars.Add(new PartCar
                    {
                        Car = currCar,
                        PartId = part
                    });
                }

                currCar.PartCars = partCars;
                cars.Add(currCar);
            }

            context.Cars.AddRange(cars);
            context.SaveChanges();

            return $"Successfully imported {cars.Count}";
        }

        public static string ImportCustomers(CarDealerContext context, string inputXml)
        {
            string root = "Customers";
            ImportCustomersDTO[] importCustomers = Deserialize<ImportCustomersDTO[]>(inputXml, root);

            Customer[] customers = importCustomers.Select(c => new Customer
            {
                Name = c.Name,
                BirthDate = c.BirthDate,
                IsYoungDriver = c.IsYoungDriver
            }).ToArray();

            context.Customers.AddRange(customers);
            context.SaveChanges();

            return $"Successfully imported {customers.Length}";
        }







        private static T Deserialize<T>(string inputXml, string rootName)
        {
            XmlRootAttribute xmlRoot = new XmlRootAttribute(rootName);
            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T), xmlRoot);

            using StringReader reader = new StringReader(inputXml);
            T dtos = (T)xmlSerializer
                .Deserialize(reader);

            return dtos;
        }
        private static string Serialize<T>(T dto, string rootName)
        {
            StringBuilder sb = new StringBuilder();

            XmlRootAttribute xmlRoot = new XmlRootAttribute(rootName);
            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(T), xmlRoot);

            using StringWriter writer = new StringWriter(sb);
            xmlSerializer.Serialize(writer, dto, namespaces);

            return sb.ToString().TrimEnd();
        }
    }
}